GullyScore Android project

This is an Android WebView wrapper that opens the included GullyScore prototype locally from the APK assets. It does not require Chrome or an internet connection to run.

Build APK:
1. Install Android Studio on a computer.
2. Open this folder (GullyScoreAndroid) in Android Studio.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be under app/build/outputs/apk/debug/app-debug.apk.

Package: com.gullyscore.app
Minimum Android: 6.0 (API 23)
